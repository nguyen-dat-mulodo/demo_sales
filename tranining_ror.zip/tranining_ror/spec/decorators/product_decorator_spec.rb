require 'rails_helper'

RSpec.describe ProductDecorator do
end
