require 'rails_helper'

RSpec.describe RoomDecorator do
end
