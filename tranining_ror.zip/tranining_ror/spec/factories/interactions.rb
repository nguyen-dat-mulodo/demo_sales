FactoryGirl.define do
  factory :interaction do
    post nil
    user nil
    like ""
    share ""
    commment ""
  end
end
