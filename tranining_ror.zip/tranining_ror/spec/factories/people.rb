FactoryGirl.define do
  factory :person do
    firstname "MyString"
    lastname "MyString"
    email "MyString"
    city "MyString"
    state "MyString"
  end
end
