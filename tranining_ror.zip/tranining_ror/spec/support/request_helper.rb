require 'spec_helper'
module RequestHelper
end